# PASS resource guard / NOT_RUN cross-model AA

8GPU worker processes passed3idle checks andResourceGuard; GPU4 used. Noforeign process or unguarded job is accepted. CPU-onlyBM25 uses noCUDA. All request repeats/16profile subgroups are cost observations, not new independent relevance labels. Models sharehardware identity but no cross-model ABBA orA/A equivalence; cross-model superiority is not claimed.
