## icde_eab_submission_gate_009 / Y1 / 2026-10-28T22:12:44.238413+08:00 北京时间

**结论**：PASS_ACTUAL_SETUP_COLD_WARM_COSTS__AMORTIZATION_CONDITIONAL。ColQwen2 load=3.392s/GPU1.049s,index=189.79s/CPU192.79s/GPU121.25s, resident-cold first=13.37s; ColPali load=7.567s/GPU1.650s,index=151.76s/CPU154.41s/GPU121.01s, resident-cold first=18.92s

**决策**：按真实依赖单次计入OCR；报告N100/1000/10000条件曲线和break-even，不替用户选择Q、不改变主结果；模型间延迟优势无AA证据。

**限制**：Biomedical160/157查询族/27来源为描述性；ColPali扩展为事后。重复不增加独立n。新K1 NOT_CERTIFIED，严格Serving未通过；本轮Cal81/Eval73和旧B-L/test/CS读取0。发布和MIT需单独批准；CMT未授权。

**证据**：reports/icde_eab_submission_gate_009/Y1/；code commit 699fd67f2d20ea7b014e2a9d3cb223253c8a27e2；manifest SHA见阶段回执。
