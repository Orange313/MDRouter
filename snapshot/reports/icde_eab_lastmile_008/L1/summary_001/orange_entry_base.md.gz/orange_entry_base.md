## icde_eab_lastmile_008 / L1_summary_001 / 2026-10-28T16:43:58.692337+08:00（北京时间）

**结论**：PASS_BIOMEDICAL_COLPALI_EXPLORATORY_POSTHOC_EXTENDED。Biomedical ColPali160，5760次真实计时/3进程×3重复，1600GPU分项；Full-Visual U=0.6377,r=0.00000[0.00000,0.00000],E2E=94.72ms; BM25-R50 U=0.5417,r=0.11091[0.06985,0.16048],E2E=88.38ms; BM25-R100 U=0.5583,r=0.09293[0.05462,0.13912],E2E=88.40ms; BM25 U=0.3807,r=0.27910[0.22356,0.34183],E2E=2.78ms

**决策**：报告同数据域双检索器的各自前沿，不把事后补充伪装预注册，不转移旧证书或模型。

**阻塞与口径**：旧四域164 Dev为探索证据；新 Biomedical 为预注册描述性评价，预训练重叠 UNKNOWN；重复计时不增加独立n。新K1 NOT_CERTIFIED，Pharma Cal81/Eval73及旧B-L/test/CS读取0。CPU/GPU/wall分列，Probe实际计费；不声称业务净收益或未经AA核验的Serving优越性。

**证据**：`PROJECT_ROOT/reports/icde_eab_lastmile_008/L1/summary_001`；code commit `42c8aee489bd4cdc10b670a5dcfbf1d0c1c8dd1a`；manifest `artifacts/icde_eab_lastmile_008/L1_summary_001/manifest.json`，SHA见随本条提交的回执；依据用户008指令与Orange17 R2、06 R68；L1为事后交叉扩展。
