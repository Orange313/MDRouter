# PASS execution / EXPLORATORY_POSTHOC_EXTENDED

Biomedical ColPali160，5760次真实计时/3进程×3重复，1600GPU分项；Full-Visual U=0.6377,r=0.00000[0.00000,0.00000],E2E=94.72ms; BM25-R50 U=0.5417,r=0.11091[0.06985,0.16048],E2E=88.38ms; BM25-R100 U=0.5583,r=0.09293[0.05462,0.13912],E2E=88.40ms; BM25 U=0.3807,r=0.27910[0.22356,0.34183],E2E=2.78ms

本实验发生在ColQwen结果已知之后，非新盲测。相同160问、1016页与OCR/分组/权重固定，无Q/QP移植。各模型使用自己的FullV，模型间硬件cohort不同，不作配对时间优越性检验。评分与candidate containment阈值保持不变；setup/OCR/GPU分项与空OCR敏感性见表，版权缺图页级标签UNKNOWN，不按风险删查询。新K1 NOT_CERTIFIED，封存读取0。

支持论文跨模型领域相关静态前沿表，不证明模型无关部署保证。
