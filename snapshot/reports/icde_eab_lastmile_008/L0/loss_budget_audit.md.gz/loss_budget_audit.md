# Original loss contract unchanged

ε=.05、δ=.01保持不变。表中每个方法的真实经验均值与两个截面详见posthoc_envelope_vs_frozen_random.csv；Q/QP/R100均>.05。FullV风险0是相对参考定义，不代表给新策略签发K1。新K1 NOT_CERTIFIED；Cal/Eval、旧B-L/test/CS读取0。Bootstrap置信区间不替代原K1证书。不存在把重复12960请求当成独立标签的n扩增。
