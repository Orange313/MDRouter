## icde_eab_lastmile_008 / L0 / 2026-10-28T15:06:54.299177+08:00（北京时间）

**结论**：PASS_DIRECT_PAIRED_DESCRIPTIVE_POINT_ESTIMATE_DOMINANCE_NOT_STABLE_IN_BOTH_SOURCE_INTERVALS。QP−R100: r=-0.017437 95%[-0.044849,0.007894], nDCG=0.009075 [-0.018533,0.037608], E2E=-4.548ms [-9.800,0.353]; LOSO双均值优势27/27。

**决策**：论文分别报告确定性R100、实际冻结RandomMix和事后理想包络；不重新选择策略、混合概率或风险参数，不申请新K1。

**阻塞与口径**：旧四域164 Dev为探索证据；新 Biomedical 为预注册描述性评价，预训练重叠 UNKNOWN；重复计时不增加独立n。新K1 NOT_CERTIFIED，Pharma Cal81/Eval73及旧B-L/test/CS读取0。CPU/GPU/wall分列，Probe实际计费；不声称业务净收益或未经AA核验的Serving优越性。

**证据**：`PROJECT_ROOT/reports/icde_eab_lastmile_008/L0`；code commit `79c822d5cf1b469ee34c1aa6e79fb4581fccea8a`；manifest `artifacts/icde_eab_lastmile_008/L0/manifest.json`，SHA见随本条提交的回执；依据用户008指令与Orange17 R2、06 R68；L1为事后交叉扩展。
