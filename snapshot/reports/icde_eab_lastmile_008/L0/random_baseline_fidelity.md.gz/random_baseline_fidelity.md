# Frozen execution versus retrospective envelope

1. Frozen RandomMix:007评价前锁定的Pharma概率、seed及SHA256按query分配；本次160个动作全部重新核对一致。原9方法实验的1440次真实路径计时/方法，未新选概率。其风险点不同于QP，不能冒充同风险对照。
2. posthoc_static_convex_envelope:在已观察到的测试风险/成本上解四静态计划凸混合，只有理想期望，不是已执行部署或独立验证的策略。风险=.05和QP经验风险两个截面全部保留；不得将它改称冻结RandomMix。

Bio RR-hard/soft各1440条完整真实请求；旧四Dev的8条RR结果是分项成本组合，没有完整路径尾延迟。两者逐行分级见fidelity_cost_source_audit.csv。本地Q150/Ridge三动作hard/soft target不是官方RetrievalRouter Qwen+LoRA+KL/五动作复现，不简称为官方模型。
